using System;
using System.Text;
using System.Runtime.InteropServices;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("Tools", "DivinityArcane", "1.0")]
public class Extension
{
    [BindCommand("base64", "Command for encoding/decoding to/from base64.", Privs.Guest, "[trig]base64 encode/decode plaintext/ciphertext")]
    public void cmd_base64(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b> {0}base64 encode/decode plaintext", LulzBot.Trigger);
            
        if (args.Length < 3)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            try
            {
                String arg = args[1];
                String input = msg.Substring(14);

                if (arg == "encode")
                    LulzBot.Say(chan, String.Format("<b>&raquo; Base64 encoded output:</b> {0}", Convert.ToBase64String(Encoding.ASCII.GetBytes(input))));
                else if (arg == "decode")
                    LulzBot.Say(chan, String.Format("<b>&raquo; Base64 decoded output:</b> {0}", Encoding.ASCII.GetString(Convert.FromBase64String(input))));
                else
                    LulzBot.Say(chan, helpmsg);
            }
            catch (Exception E)
            {
                LulzBot.Say(chan, "<b>&raquo; Failed to encode/decode:</b> " + E.Message);
            }
        }
    }
    
    [BindCommand("md5", "MD5 hash command.", Privs.Guest, "[trig]md5 plaintext")]
    public void cmd_md5(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b> {0}md5 plaintext", LulzBot.Trigger);
            
        if (args.Length < 2)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            try
            {
                String input = msg.Substring(4);

                LulzBot.Say(chan, String.Format("<b>&raquo; MD5 hash:</b> {0}", Tools.md5(input)));
            }
            catch (Exception E)
            {
                LulzBot.Say(chan, "<b>&raquo; Failed to hash:</b> " + E.Message);
            }
        }
    }
    
    [BindCommand("reverse", "Reverses a string.", Privs.Guest, "[trig]reverse text")]
    public void cmd_reverse(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b> {0}reverse text", LulzBot.Trigger);
            
        if (args.Length < 2)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            char[] input = msg.Substring(8).ToCharArray();
            Array.Reverse(input);

            LulzBot.Say(chan, String.Format("<b>&raquo; Reversed input:</b> {0}", new String(input)));
        }
    }
    
    [BindCommand("raw", "Sends a raw dAmn packet.", Privs.Owner, "[trig]raw packet_text")]
    public void cmd_raw(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b> {0}raw packet_text", LulzBot.Trigger);
            
        if (args.Length < 2)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            String input = msg.Substring(4);
            input = input.Replace("\\n", "\n");
            input = input.Replace("\\0", "\0");
            Program.Bot.Send(input);
        }
    }
    
    [BindCommand("dsay", "Delayed send command.", Privs.Owner, "[trig]dsay #seconds <i>#chan</i> message")]
    public void cmd_dsay(String chan, String msg, String[] args, String from)
    {
        String helpmsg = String.Format("<b>&raquo; Usage:</b> {0}dsay #seconds <i>#channel</i> message", LulzBot.Trigger);
            
        if (args.Length < 3)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            int secs = 0;

            bool ok = int.TryParse(args[1], out secs);

            if (!ok)
            {
                LulzBot.Say(chan, helpmsg);
                return;
            }
            
            String ns, input;
            if (args[2].StartsWith("#") && args.Length > 3)
            {
                ns = args[2];
                input = msg.Substring(7 + args[1].Length + ns.Length);
            }
            else
            {
                ns = chan;
                input = msg.Substring(6 + args[1].Length);
            }
            
            Timers.Add(secs * 1000, delegate { LulzBot.Say(ns, input); });
        }
    }
}
