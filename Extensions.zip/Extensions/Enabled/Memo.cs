using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("Memos", "DivinityArcane", "1.0")]
public class Extension
{
    Dictionary<String, List<Memo>> data = null;

    private void Load()
    {
        data = Storage.Load<Dictionary<String, List<Memo>>>("memos");

        if (data == null)
            data = new Dictionary<String, List<Memo>>();
    }

    private void Save()
    {
        Storage.Save("memos", data);
    }
    
    [BindCommand("memo", "Command for allowing users to save memos.", Privs.Members, "[trig]memo list <i>verbose</i><br/>[trig]memo write memo_text<br/>[trig]memo read/del #id")]
    public void cmd_memo(String chan, String msg, String[] args, String from)
    {
        if (data == null)
            Load();

        String helpmsg = String.Format("<b>&raquo; Usage:</b><br/>{0}memo write [something to remember]<br/>{0}memo read/del [#id]<br/>{0}memo list <i>verbose</i><br/>{0}memo clear<br/><br/><i>Verbose listing is limited to the first 5 memos.</i>", " &middot; " + LulzBot.Trigger);
            
        if (args.Length < 2)
        {
            LulzBot.Say(chan, helpmsg);
        }
        else
        {
            String arg = args[1], who = from.ToLower();

            if (arg == "write" && args.Length > 2)
            {
                Memo memo = new Memo() {
                    Timestamp = Tools.Timestamp(),
                    Body = msg.Substring(5 + arg.Length)
                };

                if (data.ContainsKey(who))
                    data[who].Add(memo);
                else
                    data.Add(who, new List<Memo>() { memo });

                Save();

                LulzBot.Act(chan, "<b>&raquo; Memo saved!</b>");
            }
            else if (arg == "read" && args.Length > 2)
            {
                if (data.ContainsKey(who))
                {
                    int id = 0;
                    bool parsed = Int32.TryParse(args[2], out id);
                    id = id - 1;

                    if (parsed && id >= 0 && id < data[who].Count)
                    {
                        Memo memo = data[who][id];

                        LulzBot.Say(chan, String.Format("<b>&raquo; Written on <i>{0}</i></b><br/><br/>{1}", Tools.strftime("%c", memo.Timestamp), memo.Body));
                    }
                    else
                    {
                        LulzBot.Say(chan, String.Format("<b>&raquo; There is no such memo for :dev{0}:</b>", from));
                    }
                }
                else
                {
                    LulzBot.Say(chan, String.Format("<b>&raquo; There are no memos for :dev{0}:</b>", from));
                }
            }
            else if (arg == "del" && args.Length > 2)
            {
                if (data.ContainsKey(who))
                {
                    int id = 0;
                    bool parsed = Int32.TryParse(args[2], out id);
                    id = id - 1;

                    if (parsed && id >= 0 && id < data[who].Count)
                    {
                        data[who].Remove(data[who][id]);
                        Save();

                        LulzBot.Say(chan, "<b>&raquo; Memo deleted!</b>");
                    }
                    else
                    {
                        LulzBot.Say(chan, String.Format("<b>&raquo; There is no such memo for :dev{0}:</b>", from));
                    }
                }
                else
                {
                    LulzBot.Say(chan, String.Format("<b>&raquo; There are no memos for :dev{0}:</b>", from));
                }
            }
            else if (arg == "list")
            {
                if (data.ContainsKey(who))
                {
                    int count = data[who].Count;

                    if (count > 0)
                    {
                        String ids = String.Empty;

                        for (int i = 0; i < count; i++)
                        {
                            if (args.Length > 2 && args[2] == "verbose")
                            {
                                if (i >= 5) break;
                                String body = Tools.StripTags(data[who][i].Body);
                                if (body.Length > 47)
                                    body = body.Substring(0, 47) + "...";
                                ids += String.Format("<br/> <b>#{0}</b>: {1}", i + 1, body);
                            }
                            else ids += String.Format(", #{0}", i + 1);
                        }

                        if (args.Length == 2)
                            ids = ids.Substring(2);

                        LulzBot.Say(chan, String.Format("<b>&raquo; There's {0} memo{1} for :dev{2}:</b><br/>{3}<br/><br/><sub>To read a memo, use {4}memo read <i>#</i></sub>",
                            count, (count == 1 ? "" : "s"), from, ids, LulzBot.Trigger));
                    }
                    else
                    {
                        LulzBot.Say(chan, String.Format("<b>&raquo; There are no memos for :dev{0}:</b>", from));
                    }
                }
                else
                {
                    LulzBot.Say(chan, String.Format("<b>&raquo; There are no memos for :dev{0}:</b>", from));
                }
            }
            else if (arg == "clear")
            {
                if (data.ContainsKey(who))
                {
                    int count = data[who].Count;

                    if (count > 0)
                    {
                        data[who].Clear();
                        Save();

                        LulzBot.Say(chan, "<b>&raquo; Memos cleared!</b>");
                    }
                    else
                    {
                        LulzBot.Say(chan, String.Format("<b>&raquo; There are no memos for :dev{0}:</b>", from));
                    }
                }
                else
                {
                    LulzBot.Say(chan, String.Format("<b>&raquo; There are no memos for :dev{0}:</b>", from));
                }
            }
        }
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 0)]
public struct Memo
{
    public int Timestamp;
    public String Body;
} 
