using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using lulzbot;
using lulzbot.Extensions;

[ExtensionInfo("BrainFuck", "DivinityArcane", "1.0")]
public class Extension
{    
    private enum OpCode : byte
    {
        IncrementPointer    = (byte)'>',
        DecrementPointer    = (byte)'<',
        IncrementValue      = (byte)'+',
        DecrementValue      = (byte)'-',
        BeginLoop           = (byte)'[',
        EndLoop             = (byte)']',
        Output              = (byte)'.',
    }   // Input is disabled.

    private string Interpret(string code)
    {
        byte[] tape                 = new byte[30000];
        short mloc                  = 0;
        bool ignore                 = false;
        var output                  = "";
        List<char> valid_opcodes    = new List<char>() { '<', '>', '[', ']', '+', '-', '.' };
        List<short> loop_locs       = new List<short>();
        var chars                   = code.ToCharArray();
        var started                 = Environment.TickCount;
        
        for (int cloc = 0; cloc < chars.Length; cloc++)
        {
            char c = chars[cloc];
            
            if (ignore)
            {
                if (c == (char)OpCode.EndLoop)
                    ignore = false;
                    
                continue;
            }   
            
            if (!valid_opcodes.Contains(c))
                if (c == ',')
                    throw new InvalidOperationException("Input is disabled");
                else
                    throw new FormatException("Invalid opcode '" + c + "' at location " + cloc);
                
            switch ((OpCode)c)
            {
                case OpCode.IncrementPointer:
                    if (mloc + 1 >= tape.Length)
                        throw new InvalidOperationException("Buffer overflow at location " + cloc);
                        
                    mloc++;
                    break;
                    
                case OpCode.DecrementPointer:
                    if (mloc - 1 < 0)
                        throw new InvalidOperationException("Buffer underflow at location " + cloc);
                        
                    mloc--;
                    break;
                    
                case OpCode.IncrementValue:
                    if (tape[mloc] + 1 > 255)
                        throw new InvalidOperationException("Memory overflow at location " + cloc);
                        
                    tape[mloc]++;
                    break;
                    
                case OpCode.DecrementValue:
                    if (tape[mloc] - 1 < 0)
                        throw new InvalidOperationException("Memory underflow at location " + cloc);
                        
                    tape[mloc]--;
                    break;
                    
                case OpCode.BeginLoop:
                    if (tape[mloc] == 0)
                        ignore = true;
                    else loop_locs.Add((short)cloc);
                    break;
                    
                case OpCode.EndLoop:
                    if (loop_locs.Count == 0)
                        throw new InvalidOperationException("End of loop at location " + cloc + " when no loops are open.");
                        
                    if (tape[mloc] == 0)
                        loop_locs.RemoveAt(loop_locs.Count - 1);
                    else cloc = loop_locs[loop_locs.Count - 1];
                    break;
                    
                case OpCode.Output:
                    output += (char)tape[mloc];
                    break;
            }
            
            if (Environment.TickCount - started >= 5000)
                throw new Exception("Interpretation exceeded the 5 second time limit.");
        }
        
        if (loop_locs.Count > 0)
            throw new InvalidOperationException(String.Format("{0} loop{1} left open. Location{1}: {2}", loop_locs.Count, loop_locs.Count == 1 ? "" : "s", String.Join(", ", loop_locs)));
        
        return output;
    }
    
    [BindCommand("brainfuck", "Brainfuck interpreter.", Privs.Guest, "[trig]brainfuck bf_code")]
    public void cmd_brainfuck(String chan, String msg, String[] args, String from)
    {
        if (args.Length == 1)
        {
            LulzBot.Say(chan, "<b>&raquo; Usage:</b> " + LulzBot.Trigger + "brainfuck <i>code</i>");
            return;
        }
        
        string code = msg.Substring(10);
        
        try
        {
            var output = Interpret(code);
            
            output = output.Replace("\0", "");
            
            LulzBot.Say(chan, "<b>&raquo; Output:</b> <bcode>" + output + "</bcode>");
        }
        catch (Exception E)
        {
            LulzBot.Say(chan, "<b>&raquo; Error during interpretation:</b> " + E.Message);
        }
    }
}
